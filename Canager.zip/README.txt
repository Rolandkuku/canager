Bonjour monsieur

Vous trouverez ci-joint, notre projet : Canager.
Nous utilisons libxml2 que vous trouverez dans la version qui vous convient ici : http://xmlsoft.org/downloads.html.

Le dossier data est à mettre à la racine du projet.
Il contient deux fichiers de test pour ne pas avoir à rentrer des data à la main.


 Bonne journée,

 Gauthier Cornette et Renaud Bellec